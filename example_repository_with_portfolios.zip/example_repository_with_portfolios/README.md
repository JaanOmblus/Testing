# Combined repository of Roth, Lind, and Smith

In this repo there are three different portfolios. One for each student.

## Roth (student ID (?))
[Roth](/Roth/README.md)
## Lind (student ID (?))
[Lind](/Lind/README.md)
## Smith (student ID (?))
[Smith](/Smith/README.md)
