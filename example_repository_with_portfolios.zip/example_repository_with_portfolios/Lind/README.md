# Portfolio of Lind (example!)
My portfolio 

## First day
- [Research records](/Lind/researches/research01/README.md)

- [Lab records](/Teamfolder/exercises/exercise01/README.md)

- [Reflection](/Lind/reflections/reflection01/README.md)

## Second day
- [Research records](/Lind/researches/research02/README.md)

- [Lab records](/Teamfolder/exercises/exercise02/README.md)

- [Reflection](/Lind/reflections/reflection02/README.md)

## Third day
- [Research records](/Lind/researches/research03/README.md)

- [Lab records](/Teamfolder/exercises/exercise03/README.md)

- [Reflection](/Lind/reflections/reflection03/README.md)

## Fourth day
- [Research records](/Lind/researches/research04/README.md)

- [Lab records](/Teamfolder/exercises/exercise04/README.md)

- [Reflection](/Lind/reflections/reflection04/README.md)

## Fifth day
- [Research records](/Lind/researches/research05/README.md)

- [Lab records](/Teamfolder/exercises/exercise05/README.md)

- [Reflection](/Lind/reflections/reflection05/README.md)

## Sixth day
- [Research records](/Lind/researches/research06/README.md)

- [Lab records](/Teamfolder/exercises/exercise06/README.md)

- [Reflection](/Lind/reflections/reflection06/README.md)

## Seventh day
- [Research records](/Lind/researches/research07/README.md)

- [Lab records - project01](/Teamfolder/project01/README.md)

- [Reflection](/Lind/reflections/reflection07/README.md)

## Eighth day
- [Research records](/Lind/researches/research08/README.md)

- [Lab records - project01](/Teamfolder/project01/README.md)

- [Reflection](/Lind/reflections/reflection08/README.md)

## Ninth day
- [Research records](/Lind/researches/research09/README.md)

- [Lab records](/Teamfolder/exercises/exercise09/README.md)

- [Reflection](/Lind/reflections/reflection09/README.md)

## Tenth day
- [Research records](/Lind/researches/research10/README.md)

- [Lab records](/Teamfolder/exercises/exercise10/README.md)

- [Reflection](/Lind/reflections/reflection10/README.md)

## Eleventh day
- [Research records](/Lind/researches/research11/README.md)

- [Lab records - project02](/Teamfolder/project02/README.md)

- [Reflection](/Lind/reflections/reflection11/README.md)

## Twelfth day
- [Research records](/Lind/researches/research12/README.md)

- [Lab records - project02](/Teamfolder/project02/README.md)

- [Reflection](/Lind/reflections/reflection12/README.md)

## Additional things
- [Helping us](/Lind/additionalThings/README.md#helping-us)

- [Helping others](/Lind/additionalThings/README.md#helping-others)

- [Extra activities](/Lind/additionalThings/README.md#extra-activities)


## Ranking for the videos

- [Ranking](/Lind/reflections/video_reflection/README.md#ranking)