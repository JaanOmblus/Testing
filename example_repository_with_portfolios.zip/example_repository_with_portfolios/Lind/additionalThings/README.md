# Additional things

## Helping us

(example)
- Beatrice:
    - Thanks for all the help for designing the portfolio


## Helping others


## Extra activities

(list your extra credit activities)


(example)
### IoTempower on the Raspberry Pi 4B (4GB)
I tried to install IoTempower on my personal Raspberry Pi 4B. I have the 4BG model and I was expecting a huge rise in performance.But that didn't work as planed.\