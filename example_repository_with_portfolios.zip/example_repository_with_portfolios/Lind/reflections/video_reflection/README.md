# Reflection of the videos for the second project


## Fitness Studio Management System

 
### Timeline
- scenario
    - about  min  sec
- technical explanation
    - about  min

### Negative points



### Positive points




### Used senors and techniques



### Conclusion


