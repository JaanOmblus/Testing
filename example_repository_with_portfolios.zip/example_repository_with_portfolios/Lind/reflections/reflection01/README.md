# Reflections

## week 1

## Lecture reflection
...


## Lab reflection
...
