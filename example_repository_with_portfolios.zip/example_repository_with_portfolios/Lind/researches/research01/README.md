# Research records 01

## Lecture slides

The slides for this lecture can be found here: ...

## Who are U?
Answer the following questions:


### What type of programming experience do you have?


### What have you done with micro controllers? Which ones have you used?


### Which single board computers do you know/have you used?


### Who is a maker or part of the maker community? What do you like/would you like about it?


### What do you already know about IoT?


### What are your expectations from this class?



## IoT

### What does Internet of Things entail?


### Domains


### Commonly used (data) protocols



### Typical devices


### What are the benefits of IoT?


### What are the challenges?

