# Teamfolder

Here we store all the exercises, pictures and projects we did in the exercise lectures of IoT.

## Exercises

Here we list all exercises.

- [exercise01][1]
...

[1]: /Teamfolder/exercises/exercise01
...

## Projects

- [project01][7]
...

[7]: /Teamfolder/project
...

## Pictures

- [pictures](/Teamfolder/pictures)